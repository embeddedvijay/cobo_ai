from __future__ import annotations

from datetime import datetime, timedelta
import uuid
from pymongo import ASCENDING, MongoClient, ReturnDocument
from pymongo.errors import DuplicateKeyError

from .settings import business_date, mongo_database, mongo_url


class Database:
    """All durable state. Raw message payload is saved before any HLA processing."""

    def __init__(self) -> None:
        self.client = MongoClient(mongo_url(), tz_aware=True)
        self.db = self.client[mongo_database()]
        self.ensure_indexes()

    @property
    def date(self) -> str:
        return business_date()

    @property
    def raw(self):
        # One durable collection prevents a 00:50 date rollover from losing an
        # unfinished reply. business_date remains a field for daily searches.
        return self.db["whatsapp_raw_messages"]

    @property
    def outbox(self):
        return self.db["whatsapp_outbox"]

    @property
    def transactions(self):
        # Same Market/<YY-MM-DD> collection used by the legacy project.
        return self.db[self.date]

    def ensure_indexes(self) -> None:
        self.raw.create_index([("client_name", ASCENDING), ("session_name", ASCENDING), ("source_jid", ASCENDING), ("message_id", ASCENDING)], unique=True)
        self.raw.create_index([("state", ASCENDING), ("source_jid", ASCENDING), ("message_timestamp", ASCENDING), ("received_at", ASCENDING)])
        self.raw.create_index([("client_name", ASCENDING), ("session_name", ASCENDING), ("settlement_state", ASCENDING), ("message_timestamp", ASCENDING)])
        self.outbox.create_index([("client_name", ASCENDING), ("session_name", ASCENDING), ("state", ASCENDING), ("next_attempt_at", ASCENDING), ("priority", ASCENDING), ("created_at", ASCENDING)])
        self.outbox.create_index([("client_name", ASCENDING), ("session_name", ASCENDING), ("delivery_jid", ASCENDING), ("settlement_state", ASCENDING), ("created_at", ASCENDING)])
        # A final native reply is tied to one original WhatsApp message. This
        # makes clicking/repeating "last" safe even after a process restart.
        self.outbox.create_index("dedupe_key", unique=True, sparse=True)
        self.transactions.create_index([("Client", ASCENDING), ("Contact", ASCENDING), ("Market", ASCENDING), ("Total", ASCENDING)])

        # A process kill can leave these transient states behind. The original
        # message/key is durable, so safe restart is to retry them, never drop them.
        self.raw.update_many({"state": "processing"}, {"$set": {"state": "received", "recovered_after_restart": datetime.utcnow()}})
        self.raw.update_many({"settlement_state": "queuing"}, {"$set": {"settlement_state": "pending", "recovered_after_restart": datetime.utcnow()}})
        # If WhatsApp already returned a message key, the only missing step was
        # our local /result acknowledgement. Mark it sent on restart; never
        # send the table again.
        self.outbox.update_many(
            {"state": "sending", "delivery_message": {"$exists": True}},
            {"$set": {"state": "sent", "recovered_after_restart": datetime.utcnow()}},
        )
        # A process/backend outage after WhatsApp send but before /delivery is
        # unknowable. Keeping it uncertain is intentionally safer than a blind
        # retry which could post the same table twice in an output group.
        self.outbox.update_many(
            {"state": "sending", "delivery_message": {"$exists": False}, "send_attempted_at": {"$exists": True}},
            {"$set": {"state": "uncertain", "recovered_after_restart": datetime.utcnow(), "last_error": "WhatsApp send attempted; delivery confirmation missing"}},
        )
        self.outbox.update_many(
            {"state": "sending", "send_attempted_at": {"$exists": False}},
            {"$set": {"state": "retry", "recovered_after_restart": datetime.utcnow()}},
        )

    def capture_raw(self, document: dict) -> tuple[dict, bool]:
        """Idempotent insert: duplicate Baileys upserts never make duplicate replies."""
        document["received_at"] = datetime.utcnow()
        document["business_date"] = self.date
        document["state"] = "received"
        document["normal_state"] = "pending"
        document["final_reply_state"] = "pending"
        document["settlement_state"] = "pending"
        try:
            self.raw.insert_one(document)
            return document, True
        except DuplicateKeyError:
            saved = self.raw.find_one({
                "client_name": document["client_name"], "session_name": document["session_name"],
                "source_jid": document["source_jid"], "message_id": document["message_id"],
            })
            return saved, False

    def claim_next_pending(self, client_name: str, session_name: str, source_jid: str | None = None) -> dict | None:
        query = {"client_name": client_name, "session_name": session_name, "state": "received"}
        if source_jid:
            query["source_jid"] = source_jid
        return self.raw.find_one_and_update(
            query,
            {"$set": {"state": "processing", "processing_at": datetime.utcnow()}},
            # WhatsApp timestamp retains start-to-end order even when an offline
            # append event delivers many messages in the same millisecond.
            sort=[("message_timestamp", ASCENDING), ("received_at", ASCENDING)],
            return_document=ReturnDocument.AFTER,
        )

    def mark_raw(self, raw_id, state: str, **extra) -> None:
        self.raw.update_one({"_id": raw_id}, {"$set": {"state": state, **extra}})

    def claim_next_final_reply(self, client_name: str, session_name: str, source_jid: str | None = None) -> dict | None:
        """Reserve one already-processed message for the end-of-day quoted reply."""
        query = {
            "client_name": client_name,
            "session_name": session_name,
            "state": {"$in": ["processed", "replied", "reply_pending"]},
            "final_reply_state": "pending",
            "legacy_reply": {"$nin": [None, ""]},
        }
        if source_jid:
            query["source_jid"] = source_jid
        return self.raw.find_one_and_update(
            query,
            {"$set": {"final_reply_state": "queuing", "final_reply_queuing_at": datetime.utcnow()}},
            sort=[("message_timestamp", ASCENDING), ("received_at", ASCENDING)],
            return_document=ReturnDocument.AFTER,
        )

    def mark_final_reply_queued(self, raw_id) -> None:
        self.raw.update_one({"_id": raw_id}, {"$set": {"final_reply_state": "queued", "final_reply_queued_at": datetime.utcnow()}})

    def pending_settlements(self, client_name: str, session_name: str, source_jid: str | None = None, limit: int = 1000) -> list[dict]:
        query = {
            "client_name": client_name,
            "session_name": session_name,
            "state": "processed",
            "settlement_state": {"$in": [None, "pending"]},
        }
        if source_jid:
            query["source_jid"] = source_jid
        return list(self.raw.find(query).sort([("message_timestamp", ASCENDING), ("received_at", ASCENDING)]).limit(limit))

    def reserve_settlement(self, raw_id) -> bool:
        result = self.raw.update_one(
            {"_id": raw_id, "settlement_state": {"$in": [None, "pending"]}},
            {"$set": {"settlement_state": "queuing", "settlement_queuing_at": datetime.utcnow()}},
        )
        return result.modified_count == 1

    def release_settlement(self, raw_id) -> None:
        self.raw.update_one({"_id": raw_id}, {"$set": {"settlement_state": "pending"}})

    def skip_settlement(self, raw_id, reason: str) -> None:
        self.raw.update_one({"_id": raw_id}, {"$set": {"settlement_state": "skipped", "settlement_skip_reason": reason}})

    def mark_settlement_queued(self, raw_id, details: dict) -> None:
        self.raw.update_one({"_id": raw_id}, {"$set": {"settlement_state": "queued", "settlement_details": details, "settlement_queued_at": datetime.utcnow()}})

    def result_document(self, business_date: str) -> dict:
        return self.db[business_date].find_one({"Result": True}) or {}

    def legacy_transaction(self, raw: dict) -> dict | None:
        return self.db[raw["business_date"]].find_one({"Message_ID": raw["message_id"], "Total": {"$exists": True}})

    def mark_legacy_transaction_settled(self, raw_id) -> None:
        raw = self.raw.find_one({"_id": raw_id})
        if raw:
            self.db[raw["business_date"]].update_one(
                {"Message_ID": raw["message_id"], "Total": {"$exists": True}},
                {"$set": {"Settled": True, "SettlementReplyAt": datetime.utcnow()}},
            )

    def add_transaction(self, document: dict) -> None:
        self.transactions.insert_one(document)

    def enqueue(self, message: dict) -> None:
        message.update({
            "state": "pending", "attempts": 0, "created_at": datetime.utcnow(),
            "next_attempt_at": datetime.utcnow(), "business_date": message.get("business_date") or self.date,
            # Lower number is not special; claim_outbox sorts this descending.
            "priority": int(message.get("priority", 50)),
            "send_attempt_id": message.get("send_attempt_id") or uuid.uuid4().hex,
        })
        try:
            self.outbox.insert_one(message)
        except DuplicateKeyError:
            # The final reply was already queued by an earlier "last" trigger.
            pass

    def mark_outbox_delivery(self, message_id: str, target_jid: str, sent_message: dict) -> None:
        from bson import ObjectId
        self.outbox.update_one(
            {"_id": ObjectId(message_id)},
            {"$set": {"delivery_jid": target_jid, "delivery_message": sent_message, "delivered_at": datetime.utcnow()}},
        )

    def mark_outbox_send_attempt(self, message_id: str) -> bool:
        """Persist intent *before* calling WhatsApp.

        A bridge that cannot create this record must not call sendMessage. This
        is what makes a failed /delivery callback non-duplicating.
        """
        from bson import ObjectId
        result = self.outbox.update_one(
            {"_id": ObjectId(message_id), "state": "sending"},
            {"$set": {"send_attempted_at": datetime.utcnow()}},
        )
        return result.modified_count == 1

    def mark_outbox_uncertain(self, message_id: str, error: str) -> None:
        """Stop automatic retries after WhatsApp accepted a send but local
        confirmation was unavailable. Operator can verify the group and use
        /resolve with sent=true or sent=false."""
        from bson import ObjectId
        self.outbox.update_one(
            {"_id": ObjectId(message_id), "state": "sending"},
            {"$set": {"state": "uncertain", "last_error": error, "updated_at": datetime.utcnow()}},
        )

    def resolve_outbox_uncertain(self, message_id: str, sent: bool) -> None:
        from bson import ObjectId
        state = "sent" if sent else "retry"
        payload = {"state": state, "resolved_at": datetime.utcnow(), "last_error": "" if sent else "Manual retry after verified unsent"}
        if not sent:
            payload["next_attempt_at"] = datetime.utcnow()
            payload["send_attempted_at"] = None
        self.outbox.update_one({"_id": ObjectId(message_id), "state": "uncertain"}, {"$set": payload})

    def pending_output_settlements(self, client_name: str, session_name: str, output_jid: str, limit: int = 1000) -> list[dict]:
        query = {
            "client_name": client_name,
            "session_name": session_name,
            "kind": "legacy_output",
            "state": "sent",
            "delivery_jid": output_jid,
            "market": {"$nin": [None, ""]},
            "settlement_payload": {"$ne": None},
            "delivery_message": {"$exists": True},
            "settlement_state": {"$in": [None, "pending"]},
        }
        return list(self.outbox.find(query).sort("created_at", ASCENDING).limit(limit))

    def reserve_output_settlement(self, outbox_id) -> bool:
        result = self.outbox.update_one(
            {"_id": outbox_id, "settlement_state": {"$in": [None, "pending"]}},
            {"$set": {"settlement_state": "queuing", "settlement_queuing_at": datetime.utcnow()}},
        )
        return result.modified_count == 1

    def release_output_settlement(self, outbox_id) -> None:
        self.outbox.update_one({"_id": outbox_id}, {"$set": {"settlement_state": "pending"}})

    def mark_output_settlement_queued(self, outbox_id, details: dict) -> None:
        self.outbox.update_one(
            {"_id": outbox_id},
            {"$set": {"settlement_state": "queued", "settlement_details": details, "settlement_queued_at": datetime.utcnow()}},
        )

    def claim_outbox(self, client_name: str, session_name: str, limit: int) -> list[dict]:
        claimed = []
        for _ in range(limit):
            item = self.outbox.find_one_and_update(
                {"client_name": client_name, "session_name": session_name, "state": {"$in": ["pending", "retry"]}, "next_attempt_at": {"$lte": datetime.utcnow()}},
                {"$set": {"state": "sending", "claimed_at": datetime.utcnow()}, "$inc": {"attempts": 1}},
                sort=[("priority", -1), ("created_at", ASCENDING)], return_document=ReturnDocument.AFTER,
            )
            if not item:
                break
            item["_id"] = str(item["_id"])
            # Node only needs the outbox id. raw_id is retained in MongoDB for
            # delivery bookkeeping, but must never leak as a BSON ObjectId in
            # the JSON response to Baileys.
            if item.get("raw_id") is not None:
                item["raw_id"] = str(item["raw_id"])
            claimed.append(item)
        return claimed

    def outbox_result(self, message_id: str, sent: bool, error: str = "") -> None:
        from bson import ObjectId
        item = self.outbox.find_one({"_id": ObjectId(message_id)})
        state = "sent" if sent else "retry"
        payload = {"state": state, "last_error": error, "updated_at": datetime.utcnow()}
        if not sent:
            # Exponential backoff avoids a disconnected WhatsApp session causing
            # a tight retry loop. Cap is five minutes.
            attempts = int((item or {}).get("attempts", 1))
            payload["next_attempt_at"] = datetime.utcnow() + timedelta(seconds=min(300, 2 ** min(attempts, 8)))
            # sendMessage itself failed, so retry is safe. The previous attempt
            # marker must not turn this known failure into an uncertain send.
            payload["send_attempted_at"] = None
        self.outbox.update_one({"_id": ObjectId(message_id)}, {"$set": payload})
        if sent and item:
            if item.get("kind") == "normal_source_reply" and item.get("raw_id"):
                self.raw.update_one({"_id": item["raw_id"]}, {"$set": {"normal_reply_state": "sent", "normal_replied_at": datetime.utcnow()}})
            elif item.get("kind") in {"final_source_reply", "source_reply"} and item.get("raw_id"):
                self.raw.update_one({"_id": item["raw_id"]}, {"$set": {"final_reply_state": "sent", "final_replied_at": datetime.utcnow()}})
            elif item.get("kind") == "settlement_source_reply" and item.get("raw_id"):
                self.raw.update_one({"_id": item["raw_id"]}, {"$set": {"settlement_state": "sent", "settlement_sent_at": datetime.utcnow()}})
                self.mark_legacy_transaction_settled(item["raw_id"])
            elif item.get("kind") == "settlement_output_reply" and item.get("reply_to_outbox_id"):
                self.outbox.update_one(
                    {"_id": item["reply_to_outbox_id"]},
                    {"$set": {"settlement_state": "sent", "settlement_sent_at": datetime.utcnow()}},
                )


db = Database()
