from __future__ import annotations

import threading

from session_bot import Session

from .database import db
from .settings import find_session


class LegacyEngine:
    """Connects the unchanged legacy Reply_processor to durable raw/outbox state."""

    def __init__(self) -> None:
        self.sessions: dict[tuple[str, str], Session] = {}
        self.session_locks: dict[tuple[str, str], threading.RLock] = {}
        self.source_locks: dict[tuple[str, str, str], threading.RLock] = {}
        self.parallel_limits: dict[tuple[str, str], threading.BoundedSemaphore] = {}

    def get_session(self, client_name: str, session_name: str) -> Session:
        key = (client_name, session_name)
        if key not in self.sessions:
            meta = find_session(client_name, session_name)

            def outbox(target: str, text: str, *, kind: str = "legacy_output", market: str | None = None, settlement_payload: dict | None = None, priority: int = 50, business_date: str | None = None):
                db.enqueue({
                    "client_name": client_name, "session_name": session_name,
                    "channel": "whatsapp", "target": target, "text": text,
                    "quote": None, "kind": kind, "raw_id": None,
                    "market": market, "settlement_payload": settlement_payload,
                    "priority": priority, "business_date": business_date,
                })

            self.sessions[key] = Session(client_name, meta["client"].get("dynamic_timing", {}), meta["client"]["fixed_market_time"], meta["session"], outbox)
            self.session_locks[key] = threading.RLock()
            max_workers = max(1, int(meta["session"].get("processing", {}).get("max_parallel_sources", 4)))
            self.parallel_limits[key] = threading.BoundedSemaphore(max_workers)
        return self.sessions[key]

    def process_one(self, raw: dict) -> dict:
        key = (raw["client_name"], raw["session_name"])
        # Session construction/scheduler setup happens once. After that each
        # source JID owns a lock, while different groups use parallel slots.
        with self.session_locks.setdefault(key, threading.RLock()):
            session = self.get_session(*key)
        source_key = (*key, raw["source_jid"])
        source_lock = self.source_locks.setdefault(source_key, threading.RLock())
        with self.parallel_limits[key], source_lock:
            reply, _reply_flag = session.process_incoming(raw["text"], raw["source_name"], raw["message_id"])
        if reply:
            # Every valid live input receives its acknowledgement immediately
            # on top of that exact WhatsApp message. raw_message contains the
            # original Baileys key + message required for native quoted reply.
            db.mark_raw(raw["_id"], "processed", normal_state="processed", legacy_reply=str(reply))
            db.enqueue({
                "client_name": raw["client_name"], "session_name": raw["session_name"],
                "channel": "whatsapp", "target": raw["source_jid"], "text": str(reply),
                "quote": raw["raw_message"], "kind": "normal_source_reply", "raw_id": raw["_id"],
                "priority": 60, "business_date": raw["business_date"],
            })
            return {"status": "processed", "reply": str(reply)}
        # The legacy processor may forward/table-send without returning a direct
        # acknowledgement. Such a message has no text available for final quote mode.
        db.mark_raw(raw["_id"], "processed", normal_state="processed", final_reply_state="skipped")
        return {"status": "processed"}


engine = LegacyEngine()
