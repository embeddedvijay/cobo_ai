from mailbox import BabylMessage
from multiprocessing.spawn import WINSERVICE
from sqlite3 import Date

from ..constants.text import text_dict,replace_dict,combine_dict,reject_msg,open_brackets,close_brackets,tax_list,flags,frame_header_list
from ..constants.number import check_num,ismotor,is_hs_ab,get_close_ring,is_fs,panal_to_ank,main_num_list
from .word_sym_process import symbol_normalize
from fuzzywuzzy import fuzz
from datetime import datetime
from copy import deepcopy
from .frame_process import frame_check,process_frames
import re

def f_match(input_str, str_list,max_ratio = 80):
    matched_str = False
    for str_item in str_list:
        ratio = fuzz.ratio(input_str, str_item)
        if ratio > max_ratio:
            max_ratio = ratio
            matched_str = True
    return matched_str

def isreject(lines:str)-> bool:
    for line in lines:
        for word in line:
            if word in reject_msg:
                return True
    return False

def confine_words(self,lines: list) -> list:
    CANCEL = False
    # risk = ''
    new_lines = []
    current_date_strs = {
        #*[datetime.now().strftime(fmt) for fmt in ("%d%m%y", "%m%d%y", "%d%m%Y","%d%m")],
        *[datetime.now().strftime(fmt) for fmt in ("%d%m%y", "%m%d%y", "%d%m%Y")],
        f'{int(datetime.now().strftime('%d'))}{int(datetime.now().strftime('%m'))}{datetime.now().strftime('%y')}',
        f'{(datetime.now().strftime('%d'))}{int(datetime.now().strftime('%m'))}{datetime.now().strftime('%y')}',
        f'{int(datetime.now().strftime('%d'))}{(datetime.now().strftime('%m'))}{datetime.now().strftime('%y')}',

        f'{int(datetime.now().strftime('%d'))}{int(datetime.now().strftime('%m'))}{datetime.now().strftime('%Y')}',
        f'{(datetime.now().strftime('%d'))}{int(datetime.now().strftime('%m'))}{datetime.now().strftime('%Y')}',
        f'{int(datetime.now().strftime('%d'))}{(datetime.now().strftime('%m'))}{datetime.now().strftime('%Y')}'
    }

    
    for line in lines:
        # print(line,new_lines)
        new_line = []
        date_raw = [x for x in line if x.isnumeric()]
        #Date Removal

        if len(date_raw) > 1 and len(date_raw) != 2 and len(date_raw) < 4 and any(''.join(date_raw[:3]) == d for d in current_date_strs):
            for date in date_raw[:3]:
                line.remove(date)
        # word map to dict name
        for word in line:
            word = word.lower()
            
            if word.isnumeric():
                new_line.append(word)
                continue
            
            appended = False
            for key, values in text_dict.items():
                if word in values or (f_match(word, values, max_ratio=91)) :
                    # print(word,key,values)
                    if new_line and key==new_line[-1]:
                        pass
                
                    elif key == 'CANCEL':
                        CANCEL = True

                    elif replace_dict.get(key, []):
                        if key[0]=='A' and len([x for x in line if x.isnumeric()])>1:
                            new_line.append(key[1:])
                            #risk += f'Unkown Numbers After All-tax line:{line}'
                        else:
                            new_line.extend(replace_dict.get(key, []))

                    else:
                        new_line.append(key)
                    appended = True
                    break
            
            if not appended and not word.isalpha():
                if new_line and new_line[-1].isalpha() :
                    pass
                elif word in open_brackets:
                    new_line.append(open_brackets[0])
                elif word in close_brackets:
                    new_line.append(close_brackets[0])
                else:
                    new_line.append(word)

        if any(x.isnumeric() or x in text_dict for x in new_line):
            if 'R' in new_line and len(new_lines)==0 and not any(x.isnumeric() for x in new_line):
                continue
            new_lines.append(new_line)

    # TO TAKE SIMPLE LINE IN AND REMOVE MISLEADING SYMBOLS
    # FIXED FORMAT IMPROVEMENT
    # ROVEMENT 
    # print("-------",new_lines)
    for line_num,line in enumerate(new_lines):
        #print(line_num,line,new_lines[line_num])
        #REJECT FM123 \N FM 235 \N FM678 MISLEDING 
        if any(x in tax_list for x in line) and len([x for x in line if x.isnumeric()])==1:
            _inline_tax = [x for x in line if x in tax_list]
            print(_inline_tax)
            if [x for x in new_lines[line_num+1] if x in tax_list] == _inline_tax and len([x for x in new_lines[line_num+1] if x.isnumeric()])==1:
                self.REJECT = True
                #print("reject")
                self.risk("Misleading Tax and 1 Num in consexutive line ")

        if any(x in line for x in tax_list) and any(x in line for x in ["SANG","HS","FS"]):
            self.REJECT = True
            self.risk(f"Sangam and tax in one line  {line}")
        temp_num_in_line = [x for x in line if x.isnumeric()]
        temp_alnum_in_line_with_dot = [x for x in line if x.isalnum() or x == '.']

        if line and ('T' in line[-1] or 'T' in line[0])  and not any(x in tax_list for x in line) or \
            (line_num and new_lines[line_num-1] and new_lines[line_num-1][-1]=='T') :
            temp_num_in_line = [x for x in line if x.isnumeric()]
            if len(temp_num_in_line)==2 and len(temp_num_in_line[1]) == 3 :
                if (line_num and new_lines[line_num-1][-1]=='T'):
                    new_lines[line_num] = [''.join(temp_num_in_line)]
                else:
                    new_lines[line_num] = ['T',''.join(temp_num_in_line)]
            elif len(temp_num_in_line)==1:
                if new_lines[line_num-1] == ["T"]:
                    new_lines[line_num-1] = []
                new_lines[line_num] = ['T',temp_num_in_line[0]]
        
        
        elif 'T' not in line :
            temp_line = [x for x in line if x in tax_list or x.isnumeric()]
            #print("before",line,temp_line)
            # n1,n2,n3...tax.r,r ---> n1,n2,n3...tax r \n n1,n2,n3 r
            if len(temp_line)>3 and (temp_line[-3] in tax_list) and \
                (temp_line[-2].isnumeric() and temp_line[-1].isnumeric()) and \
                      all(len(x)==len(temp_line[0]) for x in temp_line[:-3]):
                
                temp_amt = new_lines[line_num].pop()
                new_lines.insert(line_num+1,[*temp_line[:-3],'R',temp_amt])
            
            # n1,n2,n3...r.tax.r ---> n1,n2,n3...tax r \n n1,n2,n3 r
            elif len(temp_line)>3 and (temp_line[-2] in tax_list) and \
                (temp_line[-1].isnumeric() and temp_line[-3].isnumeric()) and \
                      all(len(x)==len(temp_line[0]) for x in temp_line[:-3]) and len(temp_line[-3])!=len(temp_line[0]):
                
                # self.REJECT = True
                # self.risk(f"Confusing Pattern of num and tax Line:{' '.join(line)}")
                temp_amt = new_lines[line_num].pop(-3)
                new_lines.insert(line_num+1,[*temp_line[:-3],'R',temp_amt])
            
            # tax 123,456, tax 10
            _taxes_list = [x for x in temp_line if x in tax_list]
            if len(set(_taxes_list))==1 and len(_taxes_list)==2:
                new_lines[line_num].pop(new_lines[line_num].index(_taxes_list[-1]))
            
            # n1,n2,n3...r.r.tax ---> n1,n2,n3...tax r \n n1,n2,n3 r
            # elif len(temp_line)>3 and (temp_line[-1] in tax_list) and \
            #     (temp_line[-2].isnumeric() and temp_line[-3].isnumeric()) and \
            #           all(len(x)==len(temp_line[0]) for x in temp_line[:-2]) and len(temp_line[-2])!=len(temp_line[-3]):
            #     self.REJECT = True
            #     print(temp_line)
            #     self.risk(f"Confusing Pattern of tax and num line:{' '.join(line)}")
                
                
       

        # if 'T' not in line:
        #     temp_line = [x for x in line if x in tax_list or x.isnumeric()]

        #     if len(temp_line)>3 and (temp_line[-3] in tax_list) and \
        #         (temp_line[-2].isnumeric() and temp_line[-1].isnumeric()) and \
        #               all(len(x)==len(temp_line[0]) for x in temp_line[:-3]):
                
        #         temp_amt = new_lines[line_num].pop()
        #         new_lines.insert(line_num+1,[*temp_line[:-3],'R',temp_amt])
        # elif 'T' in line and not any(x in tax_list for x in line):
        #     temp_num_in_line = [x for x in line if x.isnumeric()]
        #     if len(temp_num_in_line)==2 and len(temp_num_in_line[1]) == 3:
        #         new_lines[line_num] = ['T',''.join(temp_num_in_line)]

        
        
        # 9999-> 9 or 000000-> 0 etc:
        for idx,word in enumerate(line):
            if word.isnumeric() and len(word)>3 and all(x==word[0] for x in word):
                new_lines[line_num][idx] = word[0]        

        # 12345 sp 2 or 123456 2 sp ----> 12345 mpsp 2
        if any(x in ('SP','DP') for x in line) and not any(x=='MP' for x in line) and \
            len([x for x in line if x.isnumeric()])==2 and any(ismotor(x) for x in line if x.isnumeric()) :
            if 'SP' in line:
                line[line.index('SP')] = 'MPSP'
            elif 'DP' in line:
                line[line.index('DP')] = 'MPDP'

        # [n1,n2,n3..n] \n [R 5] -> [n1,n2,n3..n R 5]
        if all(len(x)==len(temp_num_in_line[0]) for x in temp_num_in_line) and not any(x.isalpha() for x in line) \
            and line_num < len(new_lines)-1 and len([x for x in new_lines[line_num+1] if x.isnumeric() ])==1 and 'R' in new_lines[line_num+1] and 'T' not in new_lines[line_num+1] :
            _len_dict = {
                'SINGLE' : 1,
                'DOUBLE' : 2,
                'PANNA' : 3
            }
            _single_double_panna = [x for x in new_lines[line_num+1] if x in _len_dict.keys()]
            if len(_single_double_panna) in (0,1) :
                if (_single_double_panna and len(temp_num_in_line[0][-1]) == _len_dict[_single_double_panna[-1]]) or (len(_single_double_panna)==0) :
                    new_lines[line_num].extend(new_lines[line_num+1])
                    new_lines[line_num+1] = []
            else:
                self.REJECT = False
                self.risk(f"Invalid names in line {new_lines[line_num]} ")
        
        if len(temp_num_in_line)>3 and all(len(x)==1 for x in [temp_num_in_line[-1],temp_num_in_line[-2]]):

            if len(temp_alnum_in_line_with_dot)>4 and 'R' in temp_alnum_in_line_with_dot[-4] and temp_alnum_in_line_with_dot[-2] == '.' and temp_alnum_in_line_with_dot[-1].isnumeric() and temp_alnum_in_line_with_dot[-3].isnumeric():
                _amt = int(temp_alnum_in_line_with_dot[-3]) + 1
                temp_alnum_in_line_with_dot.pop()
                temp_alnum_in_line_with_dot.pop()
                temp_alnum_in_line_with_dot[-1] = str(_amt)
                new_lines[line_num] = temp_alnum_in_line_with_dot

            if len(temp_alnum_in_line_with_dot)>3 and ((line_num==len(new_lines)-1) or 'T' in line) and len(temp_alnum_in_line_with_dot)>2 and temp_alnum_in_line_with_dot[-2] == '.' and temp_alnum_in_line_with_dot[-1].isnumeric() and temp_alnum_in_line_with_dot[-3].isnumeric():
                # print(temp_alnum_in_line_with_dot)
                temp_alnum_in_line_with_dot.pop()
                temp_alnum_in_line_with_dot.pop()
                new_lines[line_num] = temp_alnum_in_line_with_dot
        #close ring converter 1234 4568 340 -> 14,15,16,18 ........... 340
        if (len(temp_num_in_line)==3 and any(( (ismotor(temp_num_in_line[x]) and ismotor(temp_num_in_line[y])) for x,y in [(0,1),(1,2)]))) and not any(word in [*tax_list,*reject_msg] for word in line):
            
            if ismotor(temp_num_in_line[0]) and ismotor(temp_num_in_line[1]):
                new_lines[line_num] = [*get_close_ring(temp_num_in_line[0],temp_num_in_line[1]),'R',temp_num_in_line[2]]
               
            elif ismotor(temp_num_in_line[1]) and ismotor(temp_num_in_line[2]):
                new_lines[line_num] = [*get_close_ring(temp_num_in_line[1],temp_num_in_line[2]),'R',temp_num_in_line[0]]
        # (1) 137,128,100 ----> 137,128,100
        if len(temp_num_in_line)>3 and len(temp_num_in_line[0])==1 and (not any(x in ['HS'] for x in line)) and all(((len(x)==3 ) and panal_to_ank(x)==temp_num_in_line[0])for x in temp_num_in_line[1:] ):
            # print(f"herettt000000 {line}")
            line.pop(line.index(temp_num_in_line[0]))
            new_lines[line_num] = line

        # 123,456,789100 - 10
        if len(temp_num_in_line)>3 and all(((x[:3] in main_num_list) and (x[3:] in main_num_list)) for x in temp_num_in_line if len(x)==6) and len(temp_num_in_line[0])==3 :
            new_lines[line_num] = []
            for _w in line:
                if(_w.isnumeric() and len(_w)==6 and ((_w[:3] in main_num_list) and (_w[3:] in main_num_list)) ):
                    new_lines[line_num].append(_w[:3])
                    new_lines[line_num].append(_w[3:])
                    continue
                new_lines[line_num].append(_w)
       


    #print(new_lines)



            

    # SANGAM DETECTION and Process
    add_lines_to = {}
    #data type for this add_lines_to line_num:[[]]
    for line_num,line in enumerate(new_lines):
        temp_num_in_line = [x for x in line if x.isnumeric()]
        #result check
        if len(new_lines)==1 and  len(temp_num_in_line)==3 and len(temp_num_in_line[0])==3 and len(temp_num_in_line[1])==2 and len(temp_num_in_line[2])==3:
            self.risk(f"Result Type Message")
            self.REJECT = True
        # print(temp_num_in_line)
        if ('OP' in self.market_name) and (not any(x in [*tax_list,'T'] for x in line)):
            if any(x in line for x in ["SANG","FS"]):
                self.data["Sangam"] = True
                for _line_num,_line in enumerate(new_lines[line_num+1:]):
                    _temp_num_in_line = [x for x in _line if x.isnumeric()]
                    if len(_temp_num_in_line)==3 and len(_temp_num_in_line[0])==3 and len(_temp_num_in_line[1])==3:
                        new_lines[_line_num+line_num+1] = [f"{_temp_num_in_line[0]}{_temp_num_in_line[1]}","FS",_temp_num_in_line[-1]]
                    else:
                        if any(x in _line for x in [*tax_list,*frame_header_list]):
                            break
                        elif len(_temp_num_in_line)!=0:
                            break
            #print(line)
            elif len(temp_num_in_line)>2:
                #HSB
                #1-123,126...
                if len(temp_num_in_line)>2 and len(temp_num_in_line[0])==1 and len(temp_num_in_line[1]) ==3 and all(len(p)==3 for p in temp_num_in_line[1:-1]): 
                    # and not any(temp_num_in_line[0]==panal_to_ank(p) for p in temp_num_in_line[1:-1] ) :
                    _price = temp_num_in_line[-1]
                    _idx_till = -1
                    new_lines[line_num] = [f'{temp_num_in_line[0]}{temp_num_in_line[1]}','HSB',_price]
                    add_lines_to[line_num] = []
                    for _panal in temp_num_in_line[2:_idx_till]:
                        add_lines_to[line_num].append([f'{temp_num_in_line[0]}{_panal}','HSB',_price])
                    self.data["Sangam"] = True
                elif len(temp_num_in_line)>3 and len(temp_num_in_line[0])==1 and len(temp_num_in_line[1]) ==3 and all(len(p)==3 for p in temp_num_in_line[1:-2]) and  not any(temp_num_in_line[0]==panal_to_ank(p) for p in temp_num_in_line[1:-2] ) \
                    and (int(temp_num_in_line[-1]) == (int(temp_num_in_line[-2])*int(len([x for x in temp_num_in_line[1:-2]])))):
                    _price = temp_num_in_line[-2]
                    _idx_till = -2
                    new_lines[line_num] = [f'{temp_num_in_line[0]}{temp_num_in_line[1]}','HSB',_price]
                    add_lines_to[line_num] = []
                    for _panal in temp_num_in_line[2:_idx_till]:
                        add_lines_to[line_num].append([f'{temp_num_in_line[0]}{_panal}','HSB',_price])
                    self.data["Sangam"] = True

                #1-2-3-123...
                #preventing 1-2-3 * 300= 900 
                elif len(temp_num_in_line)>2 and len(temp_num_in_line[0])==1 and len(temp_num_in_line[-2]) ==3 and all(len(a)==1 for a in temp_num_in_line[0:-2])\
                    and (len(temp_num_in_line[:-2])*int(temp_num_in_line[-2]) != int(temp_num_in_line[-1])):
                    _price = temp_num_in_line[-1]
                    _idx_till = -2
                    new_lines[line_num] = [f'{temp_num_in_line[0]}{temp_num_in_line[-2]}','HSB',_price]
                    add_lines_to[line_num] = []
                    for _ank in temp_num_in_line[1:_idx_till]:
                        add_lines_to[line_num].append([f'{_ank}{temp_num_in_line[-2]}','HSB',_price])
                    self.data["Sangam"] = True
                elif len(temp_num_in_line)>3 and len(temp_num_in_line[0])==1 and len(temp_num_in_line[-3]) ==3 and all(len(a)==1 for a in temp_num_in_line[0:-3]) \
                    and (int(temp_num_in_line[-1]) == (int(temp_num_in_line[-2])*int(len([x for x in temp_num_in_line[0:-3]]))))\
                    and (len(temp_num_in_line[:-2])*int(temp_num_in_line[-2]) != int(temp_num_in_line[-1])):
                    _price = temp_num_in_line[-2]
                    _idx_till = -3
                    new_lines[line_num] = [f'{temp_num_in_line[0]}{temp_num_in_line[-2]}','HSB',_price]
                    add_lines_to[line_num] = []
                    for _ank in temp_num_in_line[1:_idx_till]:
                        add_lines_to[line_num].append([f'{_ank}{temp_num_in_line[-2]}','HSB',_price])
                    self.data["Sangam"] = True
                

                #12-123,126...
                elif len(temp_num_in_line)>2 and len(temp_num_in_line[0])==2 and len(temp_num_in_line[1]) ==3 and all(len(p)==3 for p in temp_num_in_line[1:-1]) and all(temp_num_in_line[0][1]==panal_to_ank(p) for p in temp_num_in_line[1:-1]):
                    _price = temp_num_in_line[-1]
                    _idx_till = -1
                    new_lines[line_num] = [f'{temp_num_in_line[0][0]}{temp_num_in_line[1]}','HSB',_price]
                    add_lines_to[line_num] = []
                    print("00000000",temp_num_in_line)
                    for _panal in temp_num_in_line[2:_idx_till]:
                        add_lines_to[line_num].append([f'{temp_num_in_line[0][0]}{_panal}','HSB',_price])
                    self.data["Sangam"] = True
                elif len(temp_num_in_line)>3 and len(temp_num_in_line[0])==2 and len(temp_num_in_line[1]) ==3 and all(len(p)==3 for p in temp_num_in_line[1:-2]) and all(temp_num_in_line[0][1]==panal_to_ank(p) for p in temp_num_in_line[1:-2]):
                    _price = temp_num_in_line[-2]
                    _idx_till = -2
                    new_lines[line_num] = [f'{temp_num_in_line[0][0]}{temp_num_in_line[1]}','HSB',_price]
                    add_lines_to[line_num] = []
                    for _panal in temp_num_in_line[2:_idx_till]:
                        add_lines_to[line_num].append([f'{temp_num_in_line[0][0]}{_panal}','HSB',_price])
                    self.data["Sangam"] = True
                ### Rejection for mismatch jodi 13-123
                elif len(temp_num_in_line)>2 and len(temp_num_in_line[0])==2 and len(temp_num_in_line[1]) ==3 and all(len(p)==3 for p in temp_num_in_line[1:-1]) and all(temp_num_in_line[0][1]!=panal_to_ank(p) for p in temp_num_in_line[1:-1]):
                    self.risk(f'Rejection for mismatch Sangam Jodi {temp_num_in_line}')
                    self.REJECT = True
                    self.data["Sangam"] = True
                
                #FS
                #123-6 6-123
                elif len(temp_num_in_line) == 4 and len(temp_num_in_line[0])==3 and len(temp_num_in_line[1])==2 and len(temp_num_in_line[2])==3 :
                    if len(temp_num_in_line)==4 and is_fs(temp_num_in_line[0],temp_num_in_line[1],temp_num_in_line[2]):
                        new_lines[line_num] = [f'{temp_num_in_line[0]}{temp_num_in_line[2]}','FS',temp_num_in_line[-1]]
                    else:
                        self.risk(f"FS Mismatched Panal to Ank (JODI) {temp_num_in_line}")
                        self.REJECT = True
                    self.data["Sangam"] = True
                    # self.risk("High Risk Full Sangam Like Pattern Found")
                #123-66-123
                elif len(temp_num_in_line) == 5 and len(temp_num_in_line[0])==3 and len(temp_num_in_line[1])==1 and len(temp_num_in_line[2])==1 and len(temp_num_in_line[3])==3 :
                    if len(temp_num_in_line)==5 and is_fs(temp_num_in_line[0],f'{temp_num_in_line[1]}{temp_num_in_line[2]}',temp_num_in_line[3]):
                        new_lines[line_num] = [f'{temp_num_in_line[0]}{temp_num_in_line[3]}','FS',temp_num_in_line[-1]]
                    else:
                        self.risk(f"FS Mismatched Panal to Ank (ank-ank) {temp_num_in_line}")
                        self.REJECT = True
                    self.data["Sangam"] = True
                #HSA
                # 123 - 63 -65 
                elif len(temp_num_in_line)>2 and len(temp_num_in_line[0])==3 and all((len(j) ==2  and  is_hs_ab(temp_num_in_line[0],j) )for j in temp_num_in_line[1:-1]) :
                    _price = temp_num_in_line[-1]
                    _idx_till = -1
                    new_lines[line_num] = [f'{temp_num_in_line[0]}{temp_num_in_line[1][1]}','HSA',_price]
                    add_lines_to[line_num] = []
                    for _jodi in temp_num_in_line[2:_idx_till]:
                        add_lines_to[line_num].append([f'{temp_num_in_line[0]}{_jodi[1]}','HSA',_price])
                    self.data["Sangam"] = True

                elif len(temp_num_in_line)>3 and len(temp_num_in_line[0])==3 and all((len(j) ==2  and  is_hs_ab(temp_num_in_line[0],j) )for j in temp_num_in_line[1:-2]) \
                    and (int(temp_num_in_line[-1]) == (int(temp_num_in_line[-2])*int(len([x for x in temp_num_in_line[1:-2]])))):
                    _price = temp_num_in_line[-2]
                    _idx_till = -2
                    new_lines[line_num] = [f'{temp_num_in_line[0]}{temp_num_in_line[1][1]}','HSA',_price]
                    add_lines_to[line_num] = []
                    for _jodi in temp_num_in_line[2:_idx_till]:
                        add_lines_to[line_num].append([f'{temp_num_in_line[0]}{_jodi[1]}','HSA',_price])
                    self.data["Sangam"] = True

                #123-4-5-6
                elif len(temp_num_in_line)>2 and len(temp_num_in_line[0])==3 and all((len(a)==1) for a in temp_num_in_line[1:-1]):
                    _price = temp_num_in_line[-1]
                    _idx_till = -1
                    new_lines[line_num] = [f'{temp_num_in_line[0]}{temp_num_in_line[1]}','HSA',_price]
                    add_lines_to[line_num] = []
                    for _ank in temp_num_in_line[2:_idx_till]:
                        add_lines_to[line_num].append([f'{temp_num_in_line[0]}{_ank}','HSA',_price])
        
                    self.data["Sangam"] = True
                elif len(temp_num_in_line)>3 and len(temp_num_in_line[0])==3 and all((len(a)==1) for a in temp_num_in_line[1:-2])\
                    and (int(temp_num_in_line[-1]) == (int(temp_num_in_line[-2])*int(len([x for x in temp_num_in_line[1:-2]])))):
                    _price = temp_num_in_line[-2]
                    _idx_till = -2
                    new_lines[line_num] = [f'{temp_num_in_line[0]}{temp_num_in_line[1]}','HSA',_price]
                    add_lines_to[line_num] = []
                    for _ank in temp_num_in_line[2:_idx_till]:
                        add_lines_to[line_num].append([f'{temp_num_in_line[0]}{_ank}','HSA',_price])
        
                    self.data["Sangam"] = True

            # if any(len(x)==3 for x in temp_num_in_line[:-1]) and any(len(x)==1 for x in temp_num_in_line[:-1]):
            #     self.REJECT = True
            #     self.risk("High Risk Sangam Like Pattern Found")
            # elif all(len(x)>3 for x in temp_num_in_line[:-1] ) and not any(x in tax_list for x in line ):
            #     new_lines[line_num] = [*temp_num_in_line[:-1],"MPSP",temp_num_in_line[-1]]
    if add_lines_to:
        _curr_idx = 0
        for line_num,ls in add_lines_to.items():
            _curr_idx += line_num
            for _i,sl in enumerate(ls):
                new_lines.insert((_curr_idx+_i+1),sl)
            _curr_idx +=len(ls)

    self.log(f"1before joingin:{new_lines}\n")
    print(f"1before joingin:{new_lines}\n")
    self.before_joining = deepcopy(new_lines)

    #Process Frame Messages
    new_lines = process_frames(new_lines)
    self.log(f"from frames:{new_lines}\n")
    #print(f"from frames:{new_lines}\n")

    new_lines = symbol_normalize(new_lines)
    can_be_price = [line[-1] for line in [[x for x in line if x.isnumeric()] for line in new_lines] if line]
    can_be_price = list(set([num for num in can_be_price if can_be_price.count(num)>1]))
    lines = []
    line = []
    #joining of all words
    self.log(f"before joingin:{new_lines}\n")

    for line_num,new_line in enumerate(new_lines):
        #print(lines,new_lines)
        for idx, word in enumerate(new_line):
            #print(word,new_line,line)
            # print(word,line)
            # try:
            #     print(word,any(word in cd for cd in combine_dict.values()) ,lines , any('line[-1]' in cd for cd in combine_dict.values()))
            # except:
            #     import traceback
            #     traceback.print_exc()
            #     pass
            # print(new_line,word,line)

            if line and ( (word =='MP' and line[-1] == 'PANNA') or (word =='PANNA' and line[-1] == 'MP')):
                if word == 'MP':
                    line.pop()
                    line.append('MP')
                continue

            elif line and word =='T' :
                #line.append('R')
                lines.append(line)
                line = []
                if len([x for x in new_line[idx+1:] if x.isnumeric()])==1:
                    line.append(word)
                    continue
                else:
                    continue


            # elif (word in tax_list) and len([x for x in new_line if x.isnumeric()])==1 and (len(new_lines) > (line_num+1)) and\
            #           any(x in tax_list for x in new_lines[line_num+1]) and len([x for x in new_lines[line_num+1] if x.isnumeric()])==1\
            #            and len([x for x in new_line if x.isnumeric()][0])==len([x for x in new_lines[line_num+1] if x.isnumeric()][0]):
            #     continue
            #elif line and 

            elif line and line[-1] == 'T':
                if word.isnumeric():
                    if any(x.isnumeric() for x in line):
                        if max([int(x) for x in line if x.isnumeric()]) < int(word):
                            line.pop()
                            lines.extend([line,['T',word]])
                            line = []
                            continue
                        elif line[-2].isnumeric()  and int(line[-2]) > int(word):
                            line.pop()
                            num = line.pop()
                            lines.extend([line,['T',num]])
                            line = []
                    else:
                        line.append(word)
                        lines.append(line)
                        line = []
                        continue

            elif line and line[-1] == 'P':
                if word.isnumeric() and len([x for x in new_line if x.isnumeric()])==1 and not any(x in tax_list for x in new_line):
                    line.pop()
                    lines.extend([line,['P',word]])
                    line = []
                    continue
                elif word.isalpha(): 
                    if not any(all(x in join_val for x in ('P',word)) for join_val in combine_dict.values()):
                        line.pop()
                        if len(line)>1 and line[-1].isnumeric() and not(any(x.isnumeric() for x in new_line[idx:])):
                            num = line.pop()
                            lines.extend([line,['P',num]])
                        elif line and line[-1].isnumeric() and len(line)==1:
                            line.insert(0,'P')
                            line.append(line)
                        elif word == 'R':
                            line.append('P')
                            continue

                        elif word in tax_list:
                            line.append(word)
                            continue
                        else:
                            lines.append(line)

                        line = []
                        continue
                    else:
                        line.pop()
                        line.append(word)
                        continue
                # elif word.isnumeric() and idx==0 :
                #     if any(x.isnumeric() for x in line):
                #         line.pop()
                #         lines.append(line)
                #     line = []
                #     line.append(word)
                #     continue
                elif word.isnumeric() and idx==0:
                    if any(x.isnumeric() for x in line):
                        if 'R' == line[-2]:
                            line.pop()
                        lines.append(line)
                    line = []
                    line.append(word)
                    # print(f'{lines}\n,{line}\n,{new_line}')
                    continue

            elif line and line[-1] == 'R' and word.isnumeric():
                line.append(word)
                if len(new_lines)-1>line_num and len(new_lines[line_num+1]) == 1 and new_lines[line_num+1][0] in tax_list:
                    if len(new_lines)-1>line_num+1 and new_lines[line_num+2] and check_num(new_lines[line_num+1][0],new_lines[line_num+2][0]):
                        lines.append(line) 
                        line = []
                        continue
                    line[-2] = new_lines[line_num+1][0]
                    new_lines.pop(line_num+1)
                    lines.append(line)
                    continue
                elif idx < len(new_line)-1 and new_line[idx+1] in tax_list:
                    continue

                lines.append(line)
                line = []
                continue

            elif len([x for x in line if x.isnumeric()])>1 and line[0] in [*tax_list,'MP'] and  (word in [*tax_list,'MP']):
                lines.append(line)
                line = []
                line.append(word)
                continue

            elif len([x for x in line if x.isnumeric()])>1 and word in [*tax_list,'MP'] and not any(x.isnumeric() for x in new_line[idx:]):
                if len(new_line)-1>idx and any(new_line[idx+1] in cd for cd in combine_dict.values()) and any(word in cd for cd in combine_dict.values()):
                    line.append(word)
                    continue
                line.append(word)
                # print(line)
                lines.append(line)
                line = []
                continue
            
            elif line and all(x.isnumeric() for x in line) and new_line[0] in tax_list and len([x for x in new_line if x.isnumeric()]) ==1:
                if word.isnumeric():
                    line.append(word)
                    lines.append(line)
                    line = []
                elif word in tax_list:
                    line.append(word)
                continue 


            elif line and line[0] in tax_list and line[-1].isnumeric() and word.isnumeric():
                if len(word) == len(line[-1]):
                    line.append(word)
                    continue
                else:
                    line.append(word)
                    lines.append(line)
                    line = []
                    continue


            elif line and line[-1].isnumeric() and word.isnumeric() and all(x.isnumeric() for x in line):
                if len(line)>1 and len([x for x in new_line if x.isnumeric()])==1 and len(new_lines)>line_num+1 and len([x for x in new_lines[line_num+1] if x.isnumeric()])==1:
                    if line_num and len([x for x in new_lines[line_num-1] if x.isnumeric()])!=1:
                        lines.append(line)
                        line = []
                    line.append(word)
                    continue
                elif idx==len(new_line)-1 and word in can_be_price:
                    if len(new_lines)-1>line_num and len(new_lines[line_num+1][0])==len(word) and len(new_lines[line_num+1])>2 and new_lines[line_num+1][-2]=='R':
                        line.append(word)
                        continue
                    line.extend(['R',word])
                    lines.append(line)
                    line = []
                    continue 
                elif len(line[-1]) == len(word):
                    line.append(word)
                    continue
                elif idx == 0:
                    lines.append(line)
                    line = []
                    line.append(word)
                    continue 
                elif any(x in tax_list for x in new_line[idx:]):
                    line.append(word)
                    continue
                else:
                    line.extend(['R',word])
                    lines.append(line)
                    line = []
                    continue    




            elif idx == 0 and line and line[-1] in tax_list:
                if word.isalpha():
                    if word == 'R':
                        continue
                    if word in tax_list and not all(x in combine_dict.values() for x in (word,line[-1]) ):
                        lines.append(line)
                        line = []

                if word.isnumeric():
                    if len([x for x in new_line if x.isnumeric()])>1:
                        if len([x for x in new_line if x in tax_list])==1 and line[-1] in new_line:
                            pass
                        elif len(line) ==1:
                            pass
                        else:
                            lines.append(line)
                            line = []

            elif idx==0 and  word in tax_list and line and line[-1].isnumeric() and len([x for x in line if  x.isnumeric()])!=1:
                lines.append(line)
                line = []

            elif idx!=0 and line and line[-1] in tax_list:
                if word.isalpha():
                    if word in ['P','R']:
                        continue
                    line.append(word)
                    continue
                elif word.isnumeric():
                    if any(x in tax_list for x in new_line[idx:]):
                        line.append(word)
                        continue

                    elif any(x.isnumeric() for x in line):
                        line.append(word)
                        lines.append(line)
                        line = []
                        continue
                else:
                    continue
                
            
            elif line and  word.isalpha() and line[-1].isalpha()  and idx == 0 and any(word in cd for cd in combine_dict.values()) and any(line[-1] in cd for cd in combine_dict.values()):
                pass



            elif line and idx == 0 and not any(x in tax_list for x in line):
                lines.append(line)
                line = []

            elif idx==len(new_line)-1 and line:

                if line_num and len([x for x in new_lines[line_num-1] if x.isnumeric()]) != 1 and len([x for x in new_line if x.isnumeric()]) == 1 and word not in tax_list :
                    line.append('R')
                    


                # elif any(x in tax_list for x in line[:2]):
                #     if line_num>0 and any(x in tax_list for x in new_lines[line_num-1]):
                        
                #     elif len([x for x in new_lines[line_num-1] if x.isnumeric()]) != len([x for x in new_line if x.isnumeric() ]):
                #         lines.append([*line,word])
                #         line = []
                #         continue



            # else:
            #     print("else ", word,new_line)

            # NONE SYMBOL BETWEEN TWO WORDS
            if word.isalpha() and (not line or line[-1] != word):

                line.append(word)
            elif word.isnumeric() or (line and line[-1].isnumeric()):
                line.append(word)
            else:
                line.append(word)
    if line:
        lines.append(line)
    
    for i,new_line in enumerate(lines):
        if any(x in ['P','T'] for x in new_line):
            lines[i] = [x for x in new_line if x!='R']
        if len(new_line)>2 and new_line[-2] == 'P' and new_line[-1].isnumeric() :
            lines[i] = new_line[:-2]
            lines.insert(i+1, new_line[-2:])



    #joining combinations from combinatin dict
    # self.log(lines)
    for i in range(3):      
        for line_num, line in enumerate(lines):
            for key, values in combine_dict.items():
                indices = [line.index(val) for val in values if val in line]
                indices.sort()
                if len(indices) == len(values) and all(abs(b - a) == 1 for a, b in zip(indices, indices[1:])):
                    lines[line_num][indices[0]] = key
                    for idx in sorted(indices[1:], reverse=True):
                        line.pop(idx)
    # return lines,CANCEL,risk
    return lines,CANCEL
                        
                




